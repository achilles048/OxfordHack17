from django.conf.urls import url
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.index, name="index" ),
    url(r'^search.html', views.search, name="search" ),
    url(r'^name.html', views.get_paper, name="get_paper" ),
    url(r'^name1.html',views.pass_rating, name="pass_rating"),

]
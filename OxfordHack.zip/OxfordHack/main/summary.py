import xml.etree.ElementTree as ET
import requests
from . import paperRank
from . import relevantpapers
from . import database


def user_in(disease):
    relevantpapers.findrelevantpapers(disease)
    relevantpapers.updatepapers(disease)
    #print( paperRank.get_top_papers(database.findDisease(disease)))
    #print(database.findDisease(disease))
    finalpap = paperRank.get_top_papers(database.findDisease(disease))
    #print(finalpap)
    return finalpap

#send=user_in(disease)
#"sent= #function giving raiyyan the paper (send)"




def rating_update(disease,prv,newrat):
    paperRank.update_rating(disease,prv,newrat)

#print(send)
"""
"disease=# raiyyan"
""
def monim(disease):
    tempap = findrelevantpapers(disease)
    finalpap= get_top_papers(tempap)
    return finalpap
"
send=monim(disease)
sent=raiyyan(send)
"


print(send)
"""
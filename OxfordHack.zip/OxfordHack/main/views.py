# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.template import loader
from .forms import NameForm, NewForm
from django.template import RequestContext
from django.views.decorators.csrf import csrf_exempt
from . import summary



@csrf_exempt
# Create your views here.

def index(request):
    template = loader.get_template('index.html')

    return HttpResponse(template.render())

def search(request):
    template = loader.get_template('search.html')

    return HttpResponse(template.render())


def get_paper(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            form = str(form)
            form = form[98:]
            i = 0
            form_value = ""
            while(form[i]!= "\""):
                form_value = form_value + form[i]
                i = i + 1
            form_value = form_value.lower()

            papers = summary.user_in(form_value)

            d = {"value": form_value, "papers": papers}
            for i in range(5):
                if i < len(papers):
                    paperval = 'paper' + str(i)
                    d[paperval + '0'] = papers[i][0]
                    d[paperval + '1'] = papers[i][1]
                    d[paperval + '2'] = papers[i][2]



            return render(request,'search.html', d)

    # if a GET (or any other method) we'll create a blank form
    else:
        form = NameForm()

    return render(request, 'name.html', {'form': form}, RequestContext(request))

def pass_rating(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = NewForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:

            form = str(form)
            form = form[103:]
            i = 0
            form_value = ""
            while(form[i]!= "\""):
                form_value = form_value + form[i]
                i = i + 1
            form_value = form_value.lower()

            print(form_value)

            return render(request,'index.html', {"value": form_value})

    # if a GET (or any other method) we'll create a blank form
    else:
        form = NameForm()

    return render(request, 'name1.html', {'form': form}, RequestContext(request))


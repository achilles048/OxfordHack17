from django import forms

class NameForm(forms.Form):
    disease = forms.CharField(label='disease', max_length=100)

class NewForm(forms.Form):
    rating_1 = forms.IntegerField(label='rating_1', min_value=1, max_value=10)
    rating_2 = forms.IntegerField(label='rating_2', min_value=1, max_value=10)
    rating_3 = forms.IntegerField(label='rating_3', min_value=1, max_value=10)
    rating_4 = forms.IntegerField(label='rating_4', min_value=1, max_value=10)
    rating_5 = forms.IntegerField(label='rating_5', min_value=1, max_value=10)
